import React from "react";
import {message} from 'antd';
import {Link} from "react-router-dom";
import {CopyToClipboard} from "react-copy-to-clipboard/lib/Component";
import {default as numeral} from 'numeral';
import CountUp from 'react-countup';
import {Utils, checkTime, AIRDROP_TIME,DAO2_RELEASE_TIME, date2CountdownString, registerToken, RBDAddress} from "../../utils/utils";
import rbd from "../../assets/images/rbd.png";
import "./Airdrop.scss";
import Countdown from "../../components/Countdown/Countdown";

class Airdrop extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      locked:0,
      init: false,
      balance: 0,
      startTime:AIRDROP_TIME,
      claimed: 0,
      claimableStart: 0,
      claimable:0,
    }
  }

  componentDidUpdate(prevProps) {

    if((this.props.address !== prevProps.address ) && Utils.web3){
      this.checkContract();
    }
  }

  componentWillUnmount = () =>{
    clearInterval(this.timer);
    clearTimeout(this.timeoutTimer);
    clearTimeout(this.claimableTimtout);
  }

  componentDidMount = () =>{
    this.timer = setInterval(()=>{this.checkContract()}, 1000);
  }

  checkContract = () =>{
    if(Utils.web3 && this.props.address){
      clearInterval(this.timer);
      if(Utils.airdrop){
        this.fetchContractData();
      }
      else{
        this.getMyBalance();
      }
    }
  }

  fetchContractData = async () =>{
      clearTimeout(this.timeoutTimer);
      this.getMyBalance();

      const startTimestamp = await Utils.airdrop.methods.startTime().call();
      const startTime = date2CountdownString(new Date(startTimestamp*1000))
      const player = await Utils.airdrop.methods.players(this.props.address).call();
      const totalRewards = Utils.web3.utils.fromWei(await Utils.airdrop.methods.getTotalRewards(this.props.address).call());
      const claimable = Utils.web3.utils.fromWei(await Utils.airdrop.methods.claimable(this.props.address).call());
      let locked = Utils.web3.utils.fromWei(player.locked) - claimable;
      let init = false;
      if(locked === 0 && totalRewards*1 > 0){
        locked = totalRewards;
        init = true;
      }
      this.setState({
        locked:locked,
        claimable:claimable,
        init:init,
        startTime:startTime,
        claimed: Utils.web3.utils.fromWei(player.claimed)
      },()=>{
        this.claimableTimtout = setTimeout(()=>{
          this.setState({
            claimableStart: claimable
          })
        }, 4000)
      })

      this.timeoutTimer = setTimeout(()=>{
        this.fetchContractData();
      },6000);
  }
  getMyBalance = () => {
    if(Utils.swap && Utils.web3 && this.props.address){

      Utils.web3.eth.getBalance(this.props.address)
      .then( (res)=>{
        this.setState({
          balance: Math.floor(Utils.web3.utils.fromWei(res) * 1000)/1000,
        })
      })
      .catch(console.log)
    }
  }

  render() {
    return (
      <div className={"airdropView"}>
        <div className={"dao2 claimBox"}>
          <h1>BeefDAO 2.0</h1>
          {
            checkTime(DAO2_RELEASE_TIME) ? <span>
            <a className={"button"} href={`https://pancakeswap.finance/swap?outputCurrency=${Utils.addresses.tokens.rbd2}`} target="_blank" rel="noopener noreferrer">
              BUY RBD2
            </a>
          </span> :<span>
            Launching In:&nbsp;
            <Countdown date={DAO2_RELEASE_TIME} />
          </span>
          }

        </div>
        <div className={"claimBox"}>
          <h1>Claim Your $RBD airdrop.</h1>
          <div className={"unlockedAmount"}>
            <div className={"itemRow"}>
              <span><img src={rbd} alt={'png'}/>To Be Unlocked</span>
              <span><b>{numeral(this.state.locked).format("0,0.[00]")} RBD</b></span>
            </div>
            <div className={"itemRow"}>
              <span><img src={rbd} alt={'png'}/>Claimed</span>
              <span><b>{numeral(this.state.claimed).format("0,0.[00]")} RBD</b></span>
            </div>
            <div className={"itemRow"}>

              <span><img src={rbd} alt={'png'}/>Claimable</span>
              <span><b>
                <CountUp
                  start={this.state.claimableStart}
                  end={this.state.claimable}
                  duration={3}
                  separator=","
                  decimals={2}
                  decimal="."
                  suffix="RBD"
                />
              </b></span>
            </div>
          </div>
          <div className={"claimNote"}>
              Vesting Duration: 180 days linear vesting.
              <br/>
              Please don't claim too frequently as you have to pay gas fee every time you claim
            </div>

            <div className={"button"} onClick={this.claim}>
              {
                checkTime(this.state.startTime)
                ? this.state.init ? "Start Vesting" : "Claim" : <Countdown date={this.state.startTime} />
              }
            </div>

          <Link to={'/farm'}>
            <div className={"button"}>
              Go To Farm
            </div>

          </Link>
        </div>
        <div className={"ruleBox"}>
          <p>3 billion tokens (30% of the total supply of BeefDAO) are claimable by Beef and Burger holders and BeefChain investors on BSC upon launch of BeefDAO.</p>
          <div className={"chart"}>
            <div className={"row"}>
              <div>Investors</div>
              <div>RBD allocated per Beef / Burger / Beefchain</div>
            </div>
            <div className={"row"}>
              <div>1 BEEF</div>
              <div>100 RBD tokens</div>
            </div>
            <div className={"row"}>
              <div>1 BURGER</div>
              <div>300 RBD tokens</div>
            </div>
            <div className={"row"}>
              <div>BeefChain Activated Account</div>
              <div>2000 RBD tokens</div>
            </div>
          </div>
          <p>Future airdrop and claim events are determined by BeefDAO.</p>
          <p>There is a 180-day claim period for all investors.<br/>After this, the unclaimed tokens are sent to the Ecosystem Fund.</p>

          <p>RBD Token Address: <span>{RBDAddress}</span></p>
          <CopyToClipboard text={RBDAddress} onCopy={()=>{message.info('Copied')}}>
            <div className={"button"}>COPY RBD Address</div>
          </CopyToClipboard>
          <p>ADDING RBD TO METAMASK.<br/>Click the button below to add RBD to your MetaMask wallet.</p>
          <div className={"button"} onClick={
            ()=>{
              registerToken(
                RBDAddress,
                'RBD',
                18,
                null
              ).then()
            }}>Add RBD to Metamask</div>

          {
            checkTime(DAO2_RELEASE_TIME) ?
              <>
                <p>RBD2 Token Address: <span>{Utils.addresses.tokens.rbd2}</span></p>
          <CopyToClipboard text={Utils.addresses.tokens.rbd2} onCopy={()=>{message.info('Copied')}}>
            <div className={"button"}>COPY RBD2 Address</div>
          </CopyToClipboard>
          <p>ADDING RBD2 TO METAMASK.<br/>Click the button below to add RBD2 to your MetaMask wallet.</p>
          <div className={"button"} onClick={
            ()=>{
              registerToken(
                Utils.addresses.tokens.rbd2,
                'RBD2',
                18,
                null
              ).then()
            }}>Add RBD2 to Metamask</div>
              </>
              : null
          }

        </div>


      </div>
    );
  }
  claim = () =>{
    if(!checkTime(this.state.startTime)){
      message.info("Coming Soon!")
      return;
    }

    if(this.state.balance < 0.001){
      message.warning('Insufficient Gas');
      return;
    }
    if(this.state.locked === 0){
      message.warning('No airdrop for your account');
      return;
    }
    try{

      Utils.airdrop.methods.claim().send({
        from: this.props.address,
      })
      .on('transactionHash', (hash)=>{
        console.log(hash);
        message.info("Transaction sent",3);
      })
      .once('receipt', res => {
        this.fetchContractData();
        message.info("Transaction confirmed",3);
      })
      .catch(err => console.log(err))
    }catch(e){
      console.log(e);
    }
  }
}

export default Airdrop;
