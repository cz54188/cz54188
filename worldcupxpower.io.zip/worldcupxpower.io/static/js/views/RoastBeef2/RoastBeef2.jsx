import React from "react";
import {default as numeral} from 'numeral';
import { Input, message, Modal } from 'antd';
import {CopyToClipboard} from 'react-copy-to-clipboard';
import CountUp from 'react-countup';
import Wallets from "../../components/Wallet/Wallets";
import {Utils, checkTime, BEEF_V2_CONTRACT_RELEASE_TIME, BEEF_V2_RELEASE_TIME, BeefV2Address} from "../../utils/utils";
import logo from "../../assets/beefv2/logo.png";
import grill from "../../assets/beefv2/grill.png";

import "./RoastBeef2.scss";
import Countdown from "../../components/Countdown/Countdown";
import WP from "../../assets/wp.pdf";
import AUDIT from "../../assets/audit.pdf";

class RoastBeef2 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      address: "xxx",
      input: 0,
      blinkMyMiners: false,
      blinkMyEarns: false,
      myEarnsStart: 0,
      myEarns:this.props.myEarns
    };

    this.render = this.render.bind(this);
  }

  componentDidUpdate = (prevProps)=>{
    if(this.props.myMiners !== prevProps.myMiners){
      this.setState({blinkMyMiners: true},()=>{
        setTimeout(()=>{
          this.setState({
            blinkMyMiners: false
          })
        }, 2000)
      })
    }

    if(this.props.myEarns !== prevProps.myEarns){
      this.setState({
        myEarns: this.props.myEarns,
        blinkMyEarns: true
      },()=>{
        setTimeout(()=>{
          this.setState({
            myEarnsStart: this.props.myEarns,
            blinkMyEarns: false
          })
        }, 3000)
      })
    }
  }

  changeInput = (val) =>{
    if(isNaN(val)){
      return;
    }
    this.setState({
      input: val
    })
  }

  toggleDisplayWalletModal = () => {
    this.setState({
      displayWalletModal: !this.state.displayWalletModal,
    });
  };

  render() {
    const { address, myMiners, contractBalance,nativeBalance } = this.props;
    const refLink = `https://roastedbeef.io/#/v2?ref=${address}`;
    return (
      <div className={"roastBeef2"}>

          <img src={logo} alt={'logo'} className={"logo"}/>

          <Modal
            visible={this.state.displayWalletModal}
            onCancel={this.toggleDisplayWalletModal}
            footer={null}
            centered={true}
            wrapClassName={'customModal'}
          >
            <Wallets
              toggleDisplayWalletModal={this.toggleDisplayWalletModal}
              address={address}
              reconnect={this.props.reconnect}
              readWeb3Instance={this.props.readWeb3Instance}
            />
          </Modal>

          <p className={"slogan"}>
            ROAST BEEF MINER V2
          </p>

          {
            checkTime(BEEF_V2_RELEASE_TIME) ? null :
              <div className={"countdownWrapper"}>
                <div>
                  <Countdown date={BEEF_V2_RELEASE_TIME}/>
                </div>
                <div>{BEEF_V2_RELEASE_TIME}</div>
              </div>
          }

        {
          checkTime(BEEF_V2_CONTRACT_RELEASE_TIME) ?
             <div className={"buttonGroup"}>
                <a href={`https://www.bscscan.com/address/${BeefV2Address}#code`} target="_blank" rel="noopener noreferrer">
                  <div className={"whitepaper"}>
                    Verified Contract
                  </div>
                </a>
              </div>
            : null
        }

          <div className={"mainContent"}>
            <div className={"box leftBox"}>
              <div className={"dataRow"}>
                <div className={"name"}>
                  Contract
                </div>
                <div className={"value"}>
                  {numeral(contractBalance).format('0,0.[0000]')} BNB
                </div>
              </div>
              <div className={"dataRow"}>
                <div className={"name"}>
                  Wallet
                </div>
                <div className={"value"}>
                  {numeral(nativeBalance).format('0,0.[0000]')} BNB
                </div>
              </div>
              <div className={"dataRow"}>
                <div className={"name"}>
                  Your Beef
                </div>
                <div className={this.state.blinkMyMiners ? "value blink_me" : "value"}>
                  {numeral(myMiners).format('0,0.[0000]')} Beef
                </div>
              </div>

              <Input
                value={`${this.state.input}`}
                onChange={(e)=>{this.changeInput(e.target.value)}}
                className={"antInput"}
                suffix={<span className={"suffix"}>BNB</span>}
              />
              <div className={"buyButton"} onClick={()=>{this.buy()}}>
                ROAST BEEF
              </div>
              <div className={"actionWrapper"}>
                <div className={"dataRow"}>
                  <div className={"name"}>
                    Your Rewards
                  </div>
                  <div className={this.state.blinkMyEarns ? "value blink_me" : "value"}>
                    <CountUp
                      start={this.state.myEarnsStart}
                      end={this.state.myEarns}
                      duration={2}
                      separator=","
                      decimals={6}
                      decimal="."
                      suffix="BNB"
                    />
                    {/*{numeral(myEarns).format('0,0.[000000]')} BNB*/}
                  </div>
                </div>
                <div className={"actionButtons"}>
                  {/*<Tooltip title={"Compound your earning beef"}>*/}
                    <div onClick={()=>{this.compound()}}>
                      RE-ROAST
                    </div>
                  {/*</Tooltip>*/}
                   <div onClick={()=>{this.withdraw()}}>
                      EAT BEEF
                    </div>
                </div>
              </div>
            </div>

            <div className={"box rightBox"}>
            <div className={"contractInfo"}>
              <img src={grill} alt={"grill"}/>
              <div className={"data"}>
                <h1>Nutrition Facts</h1>
                <div className={"dataRow"}>
                <div className={"name"}>
                  Daily Return
                </div>
                <div className={"value"}>
                  20%
                </div>
              </div>
                <div className={"dataRow"}>
                <div className={"name"}>
                  APR
                </div>
                <div className={"value"}>
                  7300%
                </div>
              </div>
                <div className={"dataRow"}>
                <div className={"name"}>
                  Dev Fee
                </div>
                <div className={"value"}>
                  0%
                </div>
              </div>
              </div>
            </div>
            <div className={"referral"}>
              <h1>Referral Link</h1>
              <p>Earn 15% of the BNB used to roast beef from anyone who uses your referral link</p>
              <div className={"refWrapper"}>
                <div className={"referralLink"}>
                {
                  address? refLink : "Connect Wallet"
                }
              </div>
              <CopyToClipboard text={refLink}
                onCopy={() => {message.info("Copied to clipboard")}}>
                <div className={"copyButton"}>
                  COPY
                </div>
              </CopyToClipboard>
              </div>

            </div>
          </div>
          </div>

      </div>
    );
  }

  buy = () =>{
    if(!checkTime(BEEF_V2_RELEASE_TIME)){
      message.info('Coming Soon');
      return;
    }
    if(!this.props.address || this.props.address === '0x00000000000000000000000000000000deadbeef'){
      this.toggleDisplayWalletModal();
      return;
    }
    if(Number(this.props.nativeBalance) < Number(this.state.input)){
      message.warning('Insufficient BNB');
      return;
    }
    if(this.state.input * 1 < 0.01){
      message.warning('Minimum deposit amount 0.01 BNB');
      return;
    }
    try{
      const callValue = Utils.web3.utils.toWei(this.state.input);
      const urlParams = new URLSearchParams(window.location.hash.split('?')[1])
      let affrAddr = urlParams.get('ref');

      let inviter = Utils.owner;
      if(Utils.web3.utils.isAddress(affrAddr)){
        inviter = affrAddr;
      }
      console.log(inviter);
      Utils.beefv2.methods.buyEggs(inviter).send({
        from: this.props.address,
        value:callValue,
      })
      .on('transactionHash', (hash)=>{
        console.log(hash);
        message.info("Transaction sent",3);
      })
      .once('receipt', res => {

        message.info("Transaction confirmed",3);
      })
      .then(res => {

      })
      .catch(err => console.log(err))
    }catch(e){
      console.log(e);
    }
  }

  compound = async () =>{
    if(!checkTime(BEEF_V2_RELEASE_TIME)){
      message.info('Coming Soon!');
      return;
    }
    if(!this.props.address || this.props.address === '0x00000000000000000000000000000000deadbeef'){
      this.toggleDisplayWalletModal();
      return;
    }
    if(this.props.nativeBalance * 1 < 0.001){
      message.warning('Insufficient Gas');
      return;
    }
    if(this.props.myEarns * 1 < 0.01){
      message.warning('Minimum Re-Roast amount must be greater than 0.01 BNB');
      return;
    }
    try{
      const urlParams = new URLSearchParams(window.location.hash.split('?')[1])
      let affrAddr = urlParams.get('ref');

      let inviter = Utils.owner;
      if(Utils.web3.utils.isAddress(affrAddr)){
        inviter = affrAddr;
      }
      console.log(inviter);
      Utils.beefv2.methods.hatchEggs(inviter).send({
        from: this.props.address,
      })
      .on('transactionHash', (hash)=>{
        console.log(hash);
        message.info("Transaction sent",3);
      })
      .once('receipt', res => {

        message.info("Transaction confirmed",3);
      })
      .then(res => {

      })
      .catch(err => console.log(err))
    }catch(e){
      console.log(e);
    }
  }

  withdraw = () =>{
    if(!checkTime(BEEF_V2_RELEASE_TIME)){
      message.info('Coming Soon!');
      return;
    }
    if(!this.props.address || this.props.address === '0x00000000000000000000000000000000deadbeef'){
      this.toggleDisplayWalletModal();
      return;
    }
    if(this.props.nativeBalance * 1 < 0.001){
      message.warning('Insufficient Gas');
      return;
    }
    try{

      Utils.beefv2.methods.sellEggs().send({
        from: this.props.address,
      })
      .on('transactionHash', (hash)=>{
        console.log(hash);
        message.info("Transaction sent",3);
      })
      .once('receipt', res => {

        message.info("Transaction confirmed",3);
      })
      .then(res => {

      })
      .catch(err => console.log(err))
    }catch(e){
      console.log(e);
    }
  }
}

export default RoastBeef2;
