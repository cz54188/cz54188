export const cardList = [
    {
        id: 'xx',
        texts: ['t1', 't1', 't1'],
        uri: '1',
    },
    {
        id: 'xx',
        texts: ['t1', 't1', 't1'],
        uri: '2',
    },
//     {
//         id: 'xx',
//         texts: ['t1', 't1', 't1'],
//         uri: '3',
//     },
//     {
//         id: 'xx',
//         texts: ['t1', 't1', 't1'],
//         uri: '4',
//     },
//     {
//         id: 'xx',
//         texts: ['t1', 't1', 't1'],
//         uri: '5',
//     },
];
