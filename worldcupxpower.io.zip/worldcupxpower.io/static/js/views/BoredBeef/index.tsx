import React, { useState, useEffect } from 'react';
import { HashRouter, Link } from 'react-router-dom';
import { message, Row, Col } from 'antd';
import Countdown from '../../components/Countdown/Countdown';
import { checkTime, BULL_RELEASE_TIME, numeral, Utils } from '../../utils/utils';
import { cardList } from './config';
import './styles.scss';

interface MyProps {
    address: string;
    nativeBalance: number | 0;
}
const Home: React.FC<MyProps> = ({ address, nativeBalance }) => {
    const [maxSupply, setMaxSupply] = useState<number>(10000);
    const [remaining, setRemaining] = useState<number>(10000);
    const [amount, setAmount] = useState<number>(1);
    const [owned, setOwned] = useState<number>(0);
    const [totalCost, setTotalCost] = useState<number>(0.1);
    const [price, setPrice] = useState<number>(0.1);
    const [canBuy, setCanBuy] = useState<boolean>(true);
    function decrease(): void {
        if (amount > 1) {
            const newAmount = amount - 1;
            setAmount(newAmount);
            setTotalCost(newAmount * price);
        }
    }

    function increase(): void {
        if (amount < 15 && amount < remaining) {
            const newAmount = amount + 1;
            setAmount(newAmount);
            setTotalCost(newAmount * price);
        }
    }

    let timeoutTimer;
    async function fetchContractData() {
        clearTimeout(timeoutTimer);
        if (Utils.web3 && Utils.bcyc && address) {
            try {
                const basePrice = await Utils.bcyc.methods.BASE_RATE().call();
                // @ts-ignore
                setPrice(Utils.web3.utils.fromWei(basePrice));

                const totalSupply = await Utils.bcyc.methods.totalSupply().call();
                const maxSupply = await Utils.bcyc.methods.MAX_SUPPLY().call();
                setMaxSupply(maxSupply);

                const remainingSupply = maxSupply * 1 - totalSupply;
                setRemaining(remainingSupply);

                const owned = await Utils.bcyc.methods.balanceOf(address).call({ from: address });
                setOwned(owned);
            } catch (e) {
                console.log(e);
            }
        }

        timeoutTimer = setTimeout(() => {
            fetchContractData();
        }, 10000);
    }

    function mint(amount: number) {
        if (!canBuy || !Utils.bcyc) {
            return;
        }

        // @ts-ignore
        Utils.bcyc.methods.mintBCYC(amount).send({from: address, value: Utils.web3.utils.toWei(totalCost.toString())})
            .on('transactionHash', (hash) => {
                console.log(hash);
                message.success('Transaction sent, please allow 10-20s to confirm', 3);
            })
            .then((res) => {
                fetchContractData();
                message.success('Mint Success', 3);
            })
            .catch((err) => {
                console.log(err);
                message.error('Transaction failed', 3);
            });
    }

    useEffect(() => {
        fetchContractData();
        setCanBuy(totalCost < nativeBalance * 1 + 0.01 && parseInt(remaining.toString()) > 0);
    }, [totalCost, nativeBalance, remaining]);

    return (
        <HashRouter>
            <div className={'boredBeef'}>
                <div className={'innerWrap mainContainer'}>

                    <div className={"bannerWrap"}>
                        <h1>Bored Cow Yacht Club</h1>
                        <p className={"slogan"}>
                        Bored Cow Yacht Club “BCYC”is 10000 unique NFTs. Holders will be granted access to exclusive rights, airdrop, new games and staking products. BCYC will be listed on OpenSea and available for trading after the mint event.
                      </p>
                    </div>

                    {checkTime(BULL_RELEASE_TIME) ? (
                        <div className={'purchaseWrap'}>
                            <h1>Mint BCYC</h1>
                            <p className={'remaining'}>
                                 BCYC Remaining
                                <span>
                                    {remaining} / {maxSupply}
                                </span>
                            </p>
                            <p className={'owned'}>
                                BCYC Owned
                                <span>{owned}</span>
                            </p>
                            <div className={'counterWrap'}>
                                <div
                                    className={'button'}
                                    onClick={() => {
                                        decrease();
                                    }}
                                >
                                    -
                                </div>
                                <div className={'amount'}>{amount}</div>
                                <div
                                    className={'button'}
                                    onClick={() => {
                                        increase();
                                    }}
                                >
                                    +
                                </div>
                            </div>

                            <p className={'totalCost'}>Total Cost {numeral(totalCost).format('0,0.[000000]')} BNB</p>
                            {canBuy ? null : parseInt(remaining.toString()) > 0 ? (
                                <p className={'insufficientBalanceNote'}>Not enough BNB to complete the transaction</p>
                            ) : null}
                            <div
                                className={'mintButton'}
                                onClick={() => {
                                    mint(amount);
                                }}
                            >
                                {parseInt(remaining.toString()) > 0 ? 'Mint' : 'Ended'}
                            </div>
                            <p className={'capNote'}>Maximum of 15 BCYC per TX.</p>
                        </div>
                    ) : (
                        <div className={'launchWrap'}>
                            <h2>Mint Countdown</h2>
                            <Countdown date={BULL_RELEASE_TIME} />
                        </div>
                    )}
                    <div className={'exWrap'}>
                        <h2>BCYC Previews</h2>
                        <div className={'exInner'}>
                            {cardList.map((item) => (
                                <img
                                    className={'nftCard'}
                                    src={`${process.env.PUBLIC_URL}/static/images/nft/${item.uri}.png`}
                                    alt={'img'}
                                    key={item.uri}
                                />
                            ))}
                        </div>

                    </div>
                </div>
            </div>
        </HashRouter>
    );
};

export default Home;
