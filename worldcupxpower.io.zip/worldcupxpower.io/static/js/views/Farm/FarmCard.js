import React, {Component} from 'react';
import {Modal, Input, message} from "antd";
import {checkTime, Utils, FARM_RELEASE_DATE} from "../../utils/utils";
import { default as ADDRESSES } from "../../utils/addresses.json";
import './FarmCard.scss';
const numeral = require('numeral');
class Farms extends Component{
  constructor(props) {
    super(props);
    this.state={
      collapsed: true,
    }
  }

  toggleCollapse = () =>{
    this.setState({
      collapsed: !this.state.collapsed
    })
  }

  handleStakeCancel = (e) => {
    this.setState({
      stakeVisible: false
    })
  }

  handleUnstakeCancel = (e) => {
    this.setState({
      unstakeVisible: false
    })
  }
  render(){
    return(
      <div className="farmCard mainContent">
        <div className={"cardHeader"}>
          <div className={"col"}>
            <div className={"name"}>Asset</div>
            <div className={"value"}>
              <img className="token1" src={`${process.env.PUBLIC_URL}/static/images/farm/tokens/${this.props.info.token1.toLowerCase()}.png`} alt={this.props.info.token1}/>
              {
                this.props.info.token2 ?
                  <img className="token2" src={`${process.env.PUBLIC_URL}/static/images/farm/tokens/${this.props.info.token2.toLowerCase()}.png`} alt={this.props.info.token2}/>
                  : null
              }
              {this.props.info.name}
            </div>
          </div>
          <div className={"col"}>
            <div className={"name"}>APY</div>
            <div className={"value"}>
              <div className={"multiplier"}>
                {this.props.info.multiplier}X
              </div>
              {numeral(this.props.data[`${this.props.id}Apy`] * 3).format('0,0.[00]%')}
            </div>
          </div>
          <div className={"col"}>
            <div className={"name"}>TVL</div>
            <div className={"value"}>
              $ {numeral(this.props.data[`${this.props.id}Tvl`]).format('0,0.[00]')}
            </div>
          </div>
          <div className={"collapse"} >
             <img src={`${process.env.PUBLIC_URL}/static/images/farm/${this.state.collapsed ? 'open' : 'close'}.png`} alt={"open"} onClick={this.toggleCollapse}/>
          </div>


        </div>

        {
          this.state.collapsed?
            null :
            <div className={"stakingDashboard"}>
              <div className={"col"}>
                <div className={"title"}>
                  Wallet Balance
                </div>
                <div className={"value"}>
                  {numeral(this.props.data[`${this.props.id}SourceInWallet`]).format('0,0.[00]')} {this.props.info.name}
                </div>
                <div className={"buttons"}>
                  {
                    this.props.data[`${this.props.id}Allowance`]  > 0 ?
                      <div className={"redButton buttonDisabled"} onClick={()=>{
                      // this.setState({
                      //   stakeVisible: true
                      // })
                  }}>
                    Deposit
                  </div>
                      :
                      <div className={"redButton"} onClick={()=>{this.approve()}}>
                    Approve
                    </div>
                  }

                  {
                    this.props.info.token2 ?
                      <a href={`https://pancakeswap.finance/add/${Utils.addresses.tokens[this.props.info.token1.toLowerCase()]}/${Utils.addresses.tokens[this.props.info.token2.toLowerCase()]}`} target="_blank" rel="noopener noreferrer">
                        <div className={"link"}>
                          Get {this.props.info.name}
                        </div>
                      </a>
                      :
                      <a href={`https://pancakeswap.finance/swap?outputCurrency=${Utils.addresses.tokens[this.props.info.token1.toLowerCase()]}`} target="_blank" rel="noopener noreferrer">
                        <div className={"link"}>
                          Get {this.props.info.name}
                        </div>
                      </a>
                  }


                </div>
              </div>

              <div className={"col"}>
                <div className={"title"}>
                  Staked Balance
                </div>
                <div className={"value"}>
                  {numeral(this.props.data[`${this.props.id}LiquidityBalance`]).format('0,0.[00]')} {this.props.info.name}
                </div>
                <div className={"buttons"}>
                  <div className={"transparentButton"} onClick={()=>{
                      this.setState({
                        unstakeVisible: true
                      })
                  }}>
                    Withdraw
                  </div>
                </div>
              </div>
              <div className={"col"}>
                <div className={"title"}>
                  Earned
                </div>
                <div className={"value"}>
                 {numeral(this.props.data[`${this.props.id}Earned`]).format('0,0.[00]')} {this.props.info.output}
                </div>
                <div className={"buttons"}>
                  <div className={"transparentButton"} onClick={this.harvest}>
                    Harvest
                  </div>

                </div>
              </div>
            </div>

        }

        <Modal
          visible={this.state.stakeVisible}
          onOk={this.handleStakeCancel}
          centered={true}
          onCancel={this.handleStakeCancel}
          footer={null}
          width={400}
          >
          <div className="stakeModalBox">
            <h2>Stake {this.props.info.name}</h2>
            <div className={"balance"}>
              Available: {numeral(this.props.data[`${this.props.id}SourceInWallet`]).format('0,0.[00]')} {this.props.info.name}
            </div>
            <Input
              suffix={
                <span
                  className="max"
                  onClick={() => {
                    this.maxStakeInput();
                  }}
                >
                  MAX
                </span>
              }
              placeholder={'0.00'}
              value={this.state.stakeInput}
              onChange={(e) => this.onChangeStakeValue(e.target.value)}
            />
            <div className={"stakeButtonWrap"}>
              <div className="cancel clickableButton transparentButton" onClick={()=>{this.handleStakeCancel()}}>
                Cancel
              </div>
              <div className="cancel clickableButton redButton" onClick={()=>{this.stake()}}>
                Confirm
              </div>
            </div>

          </div>
        </Modal>

        <Modal
          visible={this.state.unstakeVisible}
          onOk={this.handleUnstakeCancel}
          centered={true}
          onCancel={this.handleUnstakeCancel}
          footer={null}
          width={400}
          >
          <div className="stakeModalBox">
            <h2>Unstake {this.props.info.name}</h2>
            <div className={"balance"}>
              Available: {numeral(this.props.data[`${this.props.id}LiquidityBalance`]).format('0,0.[00]')} {this.props.info.name}
            </div>
            <Input
              suffix={
                <span
                  className="max"
                  onClick={() => {
                    this.maxUnstakeInput();
                  }}
                >
                  MAX
                </span>
              }
              placeholder={'0.00'}
              value={this.state.unstakeInput}
              onChange={(e) => this.onChangeUnstakeValue(e.target.value)}
            />
            <div className={"stakeButtonWrap"}>
              <div className="cancel clickableButton transparentButton" onClick={()=>{this.handleUnstakeCancel()}}>
                Cancel
              </div>
              <div className="cancel clickableButton redButton" onClick={()=>{this.unstake()}}>
                Confirm
              </div>
            </div>

          </div>
        </Modal>

      </div>
    )
  }

  maxStakeInput = () =>{
    this.onChangeStakeValue(this.props.data[`${this.props.id}SourceInWallet`])
  }

  onChangeStakeValue = (value) =>{
    if(isNaN(value)){
      return;
    }
    this.setState({
      stakeInput:value
    })
  }

  maxUnstakeInput = () =>{
    this.onChangeUnstakeValue(this.props.data[`${this.props.id}LiquidityBalance`])
  }

  onChangeUnstakeValue = (value) =>{
    if(isNaN(value)){
      return;
    }
    this.setState({
      unstakeInput:value
    })
  }

  approve = () =>{
    if(Utils[this.props.id] && Utils[this.props.id].token){
      Utils[this.props.id].token.methods.approve(Utils[this.props.id].pool._address, "0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF").send({
        from:this.props.address
      })
	    .then(res => {
        message.info("Transaction sent", 3)
        this.setState({
          stakeVisible: true
        })
	    })
	    .catch(err => console.log(err))
    }
  }

  stake = async () =>{
    if(!checkTime(this.props.data[`${this.props.id}StartTime`])){
      message.info("Not started yet!")
      return;
    }

    if(Utils[this.props.id] && Utils[this.props.id].pool){
      let stakeAmount;
      const decimal = this.props.data[`${this.props.id}SourceDecimal`];
      if(decimal === 18){
        stakeAmount = Utils.web3.utils.toWei(this.state.stakeInput);
      }
      else{
        stakeAmount = Math.floor(this.state.stakeInput * Math.pow(10, decimal))
      }
      let inviter = ADDRESSES.inviter.toLowerCase() === this.props.address.toLowerCase() ? Utils.addresses.zero : ADDRESSES.inviter;
      const urlParams = new URLSearchParams(window.location.hash.split('?')[1])
      let affrAddr = urlParams.get('ref');
      const curInviter = await Utils.poolReferral.methods.getInviter(this.props.address).call()

      if(curInviter !== Utils.addresses.zero && ADDRESSES.inviter.toLowerCase() !== this.props.address.toLowerCase()){
        inviter = curInviter
      }
      else if(Utils.web3.utils.isAddress(affrAddr) && ADDRESSES.inviter.toLowerCase() !== this.props.address.toLowerCase()){
        inviter = affrAddr
      }
      console.log(inviter)
      try{
        Utils[this.props.id].pool.methods.stake(stakeAmount, inviter).send({
          from: this.props.address
        })
          .on('transactionHash', (hash) => {
            console.log(hash)
            message.info("Transaction sent", 3)
          })
          .then(()=>{
            message.info("Deposit success", 3)
        }).catch(err=>{
          console.log(err)
        })

      } catch(err){
        console.log(err)
      }
    }
  }

  unstake = async () =>{
    if(Utils[this.props.id] && Utils[this.props.id].pool){
      let unstakeAmount = Utils.web3.utils.toWei(this.state.unstakeInput.toString());
      try{
        let res = await Utils[this.props.id].pool.methods.withdraw(unstakeAmount).send({
          from: this.props.address
        })
        .on('transactionHash', (hash) => {
            console.log(hash)
            message.info("Transaction sent", 3)
          })
        console.log(res);
        message.info("Transaction sent", 3)
      } catch(err){
        console.log(err)
      }
    }
  }

  harvest = () =>{
    if(Utils[this.props.id] && Utils[this.props.id].pool && this.props.data[`${this.props.id}Earned`] > 0){
      Utils[this.props.id].pool.methods.getReward().send({
        from: this.props.address
      })
        .on('transactionHash', (hash) => {
            console.log(hash)
            message.info("Transaction sent", 3)
          })
	    .catch(err => console.log(err))
    }
  }
}

export default Farms;
