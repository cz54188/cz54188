import React, {Component} from 'react';
import {farmList} from './config';
import FarmCard from './FarmCard'
import Countdown from "../../components/Countdown/Countdown";
import FarmReferral from "../../components/FarmReferral/FarmReferral";
import { default as ERC20Pool } from "../../utils/ERC20Pool.json";
import { default as IERC20 } from "../../utils/IERC20.json";
import {
  checkTime,
  DAO2_RELEASE_TIME,
  date2CountdownString,
  FARM_RELEASE_DATE,
  multiCall,
  Utils,
  YEAR
} from "../../utils/utils";
import "./Farm.scss";

const numeral = require("numeral");

class Farm extends Component{
  constructor() {
    super();
    this.state = {
      nativePrice: 0,
      mainTokenPrice: 0,
      tdePrice: 0,
      tvl:0
    }
  }

  componentDidMount = () => {
    this.timer = setInterval(()=>{this.checkContract()}, 1000);
  }

  componentDidUpdate = (prevProps) => {
    if(this.props.address !== prevProps.address){
      this.checkContract();
    }
  }

  componentWillUnmount = () =>{
    clearInterval(this.timer);
    clearTimeout(this.timeoutTimer);
  }

  checkContract=()=>{
    if(Utils.web3 ){
      clearInterval(this.timer);
      this.getPoolStats().then();
    }
  }


  getMainTokenPrice = async () => {
    // calc celt price
    try {
      if (Utils.mainToken) {
        const native1stableCoinPair = await Utils.swapFactory.methods
          .getPair(Utils.addresses.tokens.wrappedNative, Utils.addresses.tokens.stableCoin)
          .call();
        const stableCoinBalanceAtNative1StableCoinPair = await Utils.stableCoin.methods
          .balanceOf(native1stableCoinPair)
          .call();
        const nativeBalanceAtBusdPair = await Utils.wrappedNative.methods.balanceOf(native1stableCoinPair).call();
        const nativePrice = parseInt(stableCoinBalanceAtNative1StableCoinPair) / parseInt(nativeBalanceAtBusdPair);
        // console.log(nativePrice);
        const mainToken1NativePair = await Utils.swapFactory.methods
          .getPair(Utils.addresses.tokens.mainToken, Utils.addresses.tokens.wrappedNative)
          .call();
        const nativeBalanceAtPair = await Utils.wrappedNative.methods.balanceOf(mainToken1NativePair).call();
        const mainTokenBalanceAtPair = await Utils.mainToken.methods.balanceOf(mainToken1NativePair).call();
        let mainTokenPrice = (parseInt(nativeBalanceAtPair) * nativePrice / parseInt(mainTokenBalanceAtPair));

        // console.log(mainTokenPrice);
        if (isNaN(mainTokenPrice)) {
          mainTokenPrice = 0;
        }

        this.setState(
          {
            nativePrice: nativePrice,
            mainTokenPrice: mainTokenPrice,
          }
        );
      }
    } catch (e) {
      console.log(e);
    }
  };

  getPoolStats = async () => {
    clearTimeout(this.getPoolStatsTimer);
    clearTimeout(this.readPriceTimer);
    this.getMainTokenPrice();
    if (this.state.nativePrice === 0 && this.state.mainTokenPrice === 0) {
      this.readPriceTimer = setTimeout(() => {
        this.getPoolStats();
      }, 500);
      return;
    }


    const keys = Object.keys(Utils.liquidityPools);

    for (let i = 0; i < keys.length; i++) {
      try {
        const item = keys[i];
        if (!Utils[item] || !Utils[item].token || !Utils[item].pool) {
          continue;
        }
        const pool = Utils.liquidityPools[item];
        const newState = {};
        // calc tokenPrice
        if (pool.isLp) {
          const token1ToWrappedNativePairAddress = await Utils.swapFactory.methods
            .getPair(Utils[pool.token1.toLowerCase()]._address, Utils.addresses.tokens.wrappedNative)
            .call();
          const tokenPriceCalls = [];
          tokenPriceCalls.push([Utils.wrappedNative._address, 'balanceOf', [token1ToWrappedNativePairAddress]]);
          tokenPriceCalls.push([Utils[pool.token1.toLowerCase()]._address, 'balanceOf', [token1ToWrappedNativePairAddress]]);
          tokenPriceCalls.push([Utils[pool.token1.toLowerCase()]._address, 'balanceOf', [Utils.addresses[item].token]]);
          tokenPriceCalls.push([Utils[item].token._address, 'totalSupply', []]);

          const callRes = await multiCall(IERC20.abi, tokenPriceCalls);
          const wnativeBalanceAtWrappedNativePair = callRes[0][0];
          const token1BalanceAtWrappedNativePair = callRes[1][0];
          const token1Price = parseInt(wnativeBalanceAtWrappedNativePair) / parseInt(token1BalanceAtWrappedNativePair) * this.state.nativePrice;;
          const token1BalanceAtLpPair = Utils.web3.utils.fromWei(callRes[2][0].toString());
          const lpTotalSupply = Utils.web3.utils.fromWei(callRes[3][0].toString());
          const lpPrice = (token1Price * parseFloat(token1BalanceAtLpPair) * 2) / parseFloat(lpTotalSupply);
          newState[`${item}TokenPrice`] = lpPrice;
          // console.log(lpPrice)
        } else {
          if (pool.token1.includes('usd')) {
            newState[`${item}TokenPrice`] = 1;
          } else if (pool.token1.includes('wbnb')) {
            newState[`${item}TokenPrice`] = this.state.nativePrice;
          } else if (pool.token1.includes('celt')) {
            newState[`${item}TokenPrice`] = this.state.mainTokenPrice;
          } else {
            let token1ToWrappedNativePairAddress = await Utils.swapFactory.methods
              .getPair(Utils[pool.token1.toLowerCase()]._address, Utils.addresses.tokens.wrappedNative)
              .call();
            const wnativeBalanceAtWrappedNativePair = await Utils.wrappedNative.methods
              .balanceOf(token1ToWrappedNativePairAddress)
              .call();
            const token1BalanceAtWrappedNativePair = await Utils[pool.token1.toLowerCase()].methods
              .balanceOf(token1ToWrappedNativePairAddress)
              .call();
            const token1Price =
              (parseInt(wnativeBalanceAtWrappedNativePair) / parseInt(token1BalanceAtWrappedNativePair)) *
              this.state.nativePrice;
            newState[`${item}TokenPrice`] = token1Price;
          }
        }

        const decimals = parseInt(await Utils[item].token.methods.decimals().call());
        const poolCalls = [];
        poolCalls.push([Utils[item].pool._address, 'totalSupplySource', []]);
        poolCalls.push([Utils[item].pool._address, 'rewardRate', []]);
        poolCalls.push([Utils[item].pool._address, 'starttime', []]);
        poolCalls.push([Utils[item].pool._address, 'balanceSourceOf', [this.props.address]]);
        poolCalls.push([Utils[item].pool._address, 'earned', [this.props.address]]);

        const poolRes = await multiCall(ERC20Pool.abi, poolCalls);
        // calc tvl
        let totalTokenStaked = Utils.web3.utils.fromWei(poolRes[0][0].toString());
        if (decimals !== 18) {
          totalTokenStaked = parseInt(poolRes[0][0].toString()) / Math.pow(10, decimals);
        }
        newState[`${item}TotalStaked`] = totalTokenStaked;
        const tokenTvl = parseFloat(totalTokenStaked) * parseFloat(newState[`${item}TokenPrice`]);
        newState[`${item}Tvl`] = tokenTvl;

        // calc apy
        const tokenRewardRate = Utils.web3.utils.fromWei(poolRes[1][0].toString());
        // console.log(item, tokenRewardRate);
        // console.log(item, tokenRewardRate * 86400);
        // console.log(item, await Utils[item].pool.methods.isInteracted(this.props.address).call());
        let poolApr = (tokenRewardRate * YEAR * this.state.mainTokenPrice) / parseFloat(tokenTvl);
        if (!isNaN(poolApr) && poolApr !== Infinity) {
          newState[`${item}Apy`] = poolApr;
        }

        // get startTime
        const startTime = poolRes[2][0].toString();
        newState[`${item}StartTime`] = date2CountdownString(new Date(parseInt(startTime) * 1000));

        // calc user balance
        let myLiquidityBalance = Utils.web3.utils.fromWei(poolRes[3][0].toString());
        const myLiquidityBalanceValue = parseFloat(myLiquidityBalance) * parseFloat(newState[`${item}TokenPrice`]);
        newState[`${item}LiquidityBalance`] = myLiquidityBalance;
        newState[`${item}LiquidityBalanceValue`] = myLiquidityBalanceValue;

        newState[`${item}Earned`] = Utils.web3.utils.fromWei(poolRes[4][0].toString());

        let sourceInWallet = Utils.web3.utils.fromWei(await Utils[item].token.methods.balanceOf(this.props.address).call())
        if(decimals !== 18){
          sourceInWallet = availableSourceInWallet/ Math.pow(10, decimals);
        }
        newState[`${item}SourceInWallet`] = sourceInWallet < 0.0000009 ? 0 : sourceInWallet

        const sourceAllowance = (await Utils[item].token.methods.allowance(this.props.address, Utils[item].pool._address).call());
        newState[`${item}Allowance`] = Number(sourceAllowance)
        newState[`${item}SourceDecimal`] = decimals;

        this.setState(newState, () => {
          this.updateTvl();
        });
      } catch (e) {
        console.log(keys[i], e);
      }
    }

    this.getPoolStatsTimer = setTimeout(() => {
      this.getPoolStats();
    }, 6000);
  };

  updateTvl = () => {
    let tvl = 0;

    Object.keys(Utils.liquidityPools).map(async (item, index) => {
      if (parseFloat(this.state[`${item}Tvl`]) > 0) {
        tvl += parseFloat(this.state[`${item}Tvl`]);
      }
    });

    this.setState({
      tvl: tvl,
    });
  };
  render(){

    return(
      <div className="farm" align="left">

          <div className="banner">
            <div className={"mainContent"}>
              <div>
                <h2>BeefDAO Farm</h2>
                <h1>The Revolutionary Yield Farming System on Binance Smart Chain</h1>
              </div>

              {
                checkTime(FARM_RELEASE_DATE) ?
                  <div className={'countdownWrap'}>
                    <h2>TVL: </h2>
                    <div>
                      <strong>
                        {numeral(this.state.tvl).format('$0,0.[00]')}
                      </strong>
                    </div>
                  </div>:
                  <div className={'countdownWrap'}>
                <h2>Mining Starts In: </h2><Countdown date={FARM_RELEASE_DATE}/>
              </div>
              }

            </div>
            {
              checkTime(DAO2_RELEASE_TIME) ?
                <div className={"buttons"}>
              <a href={`https://pancakeswap.finance/swap?outputCurrency=${Utils.addresses.tokens.rbd2}`} target="_blank" rel="noopener noreferrer">
              <div className={"buyToken"}>
                Buy RBD2
              </div>
            </a>

             <a href={`https://www.dextools.io/app/bsc/pair-explorer/0xc9640e00F25677E5A91C7d55b95DD0553f83Df66`} target="_blank" rel="noopener noreferrer">
              <div className={"buyToken"}>
                Chart
              </div>
            </a>
            </div> :
                <div className={"buttons"}>
              <a href={`https://pancakeswap.finance/swap?outputCurrency=${Utils.addresses.tokens.rbd}`} target="_blank" rel="noopener noreferrer">
              <div className={"buyToken"}>
                Buy RBD
              </div>
            </a>

             <a href={`https://www.dextools.io/app/bsc/pair-explorer/0xb21faa8a0be72af653a9e4a4db12d96152965eca`} target="_blank" rel="noopener noreferrer">
              <div className={"buyToken"}>
                Chart
              </div>
            </a>
            </div>
            }


            <div className={"dao2 claimBox"}>
              <h1>BeefDAO 2.0</h1>
              {
                checkTime(DAO2_RELEASE_TIME) ? null :<span>
                Launching In:&nbsp;
                <Countdown date={DAO2_RELEASE_TIME} />
              </span>
              }

            </div>


        </div>


        <div className={"farmWrap"}>
          <div className={"farmInner"}>
            {
              Object.keys(farmList).map((item) => {
                return <FarmCard address={this.props.address} id={item} info={farmList[item]} key={item} data={this.state}/>
              })
            }
          </div>
        </div>

        <FarmReferral
          address={this.props.address}
        />




      </div>
    )
  }
}

export default Farm;
