export const farmList = {
  "rbd1bnb2rbd":{
    name: "RBD-BNB LP",
    token1: "RBD",
    token2: 'BNB',
    output: "RBD",
    multiplier: 10,
    isLp: true
  },

  "usdt2rbd":{
    name:"USDT",
    token1: "USDT",
    token2: null,
    output: "RBD",
    multiplier: 3
  },
  "busd2rbd":{
    name:"BUSD",
    token1: "BUSD",
    token2: null,
    output: "RBD",
    multiplier: 3
  },
  "wbnb2rbd":{
    name:"WBNB",
    token1: "WBNB",
    token2: null,
    output: "RBD",
    multiplier: 3
  },
}