import React, {Component} from 'react';
import {Row, Col,message,Input} from 'antd';
import {Utils, checkTime, isContract, SWAP_RELEASE_TIME} from "../../utils/utils.js";
// import CountUp from "react-countup";
import LargeBurger from "../../assets/images/largeBurger.png";
import BNBLogo from "../../assets/images/BNBlogo.png";
import Burger from "../../assets/images/burger.png";
import BurgerIcon from "../../assets/images/burgerIcon.png";
import './Investment.scss';

let timer=null;
let numeral=require('numeral');
class Investment extends Component{
  constructor(props){
    super(props);
    this.state={
      tokenToTrons:0,
      buyInputValue: '',
      sellPrice:"0.00000000001",
      buyPrice:"0.0000000001",
      bnbBalance:0,
      bnbBalanceValue:0,
      buyPriceValue:0,
      sellPriceValue:0,
      sellInputValue:'',
      sellSliderValue:0,
      diaBuy:0,
      bnbSell:0,
      affAddr: "0x0000000000000000000000000000000000000000",
      tab: 'buy'
    }
  }

    componentDidMount = () =>{
      timer = setInterval(()=>{this.checkContract()}, 1000);

      const urlParams = new URLSearchParams(window.location.hash.split('?')[1])
      let affAddr = urlParams.get('ref');

      this.setState({
        affAddr: affAddr
      })
    }

    componentDidUpdate(prevProps) {

      if(this.props.address !== prevProps.address && Utils.web3){
        this.checkContract();
      }
    }

    checkContract=()=>{
      if(Utils.web3 && this.props.address){
        clearInterval(timer);
        if(checkTime() && Utils.swap){
          this.fetchContractData();
        }
        else{
          this.getEthBalance();
        }
      }
    }

    componentWillUnmount = () =>{
      clearInterval(timer);
      clearTimeout(this.timeout);
      clearTimeout(this.bnbBalanceValueTimeout);
    }

    fetchContractData = () =>{
      clearTimeout(this.timeout);
      this.getEthBalance();
      this.getSellPrice();
      this.getBuyPrice();

      this.timeout = setTimeout(()=>{
        this.fetchContractData();
      },10000);
    }

    onBuyValueChange = value => {
      if(isNaN(value)){
        return;
      }
      this.setState({
        buyInputValue: value,
      },()=>{
        this.bnbToMiners(value);
      });
    }

    onSellValueChange = value => {
      if(isNaN(value)){
        return;
      }
      this.setState({
        sellInputValue: value,
      },()=>{
        this.tokenToEth(value);
      });
    };



    getEthBalance=()=>{
      clearTimeout(this.bnbBalanceValueTimeout);
      Utils.web3.eth.getBalance(this.props.address)
      .then( (res)=>{

        this.setState({
          bnbBalance: Math.floor(Utils.web3.utils.fromWei(res) * 10000)/10000,
        },()=>{
          if(this.props.bnbPrice > 0){
            this.setState({
              bnbBalanceValue:Math.floor(Utils.web3.utils.fromWei(res)*this.props.bnbPrice* 10000)/10000
            })
          }
          else{
            this.bnbBalanceValueTimeout = setTimeout(()=>{
              this.getEthBalance();
            },1000)
          }
        })
      })
      .catch(console.log)
    }

    getBuyPrice = () =>{
      Utils.swap.methods.buyPrice().call({
        from: this.props.address
      })
      .then(res => {
        this.setState({
          buyPrice:parseFloat(Utils.web3.utils.fromWei(res)).toFixed(7),
          buyPriceValue:Math.floor(parseFloat(Utils.web3.utils.fromWei(res)) *this.props.bnbPrice*100000)/100000
        })
      })
      .catch(err =>console.log(err))
    }

    getSellPrice = () =>{
      Utils.swap.methods.sellPrice().call({
        from: this.props.address
      })
      .then(res => {
        this.setState({
          sellPrice: parseFloat(Utils.web3.utils.fromWei(res)).toFixed(7),
          sellPriceValue:Math.floor(Utils.web3.utils.fromWei(res) *this.props.bnbPrice* 10000)/10000
        })
      })
      .catch(err =>console.log(err))
    }

    bnbToMiners=(bnb)=>{
      if(Utils.swap &&  bnb){
        Utils.swap.methods.calculateTokensReceived(Utils.web3.utils.toWei((bnb).toString())).call({
          from: this.props.address
        })
        .then(res => {
          this.setState({
            diaBuy:Utils.web3.utils.fromWei(res)
          })
        })
        .catch(err =>console.log(err))
      }
    }

    tokenToEth=(token)=>{
      if(Utils.swap  &&  token){
        Utils.swap.methods.calculateEthereumReceived(Utils.web3.utils.toWei(token.toString())).call({
          from: this.props.address
        })
        .then(res => {
          this.setState({
            bnbSell:Utils.web3.utils.fromWei(res)
          })
        })
        .catch(err =>console.log(err))
      }
    }

    buyToken = async () =>{
      if(Utils.web3 && Utils.swap && await isContract(Utils.swap._address)){
        if(!this.props.address){
          message.warning(this.props.languageFile.notification.loginPrompt)
        }
        else{
          if(checkTime(SWAP_RELEASE_TIME)){
            if(parseFloat(this.state.buyInputValue.toString())>0){
              let defaultAddress = Utils.swapOwner;
              let affAddr = Utils.web3.utils.isAddress(this.state.affAddr) ? this.state.affAddr : defaultAddress;
              Utils.swap.methods.buy(affAddr).send({
                value: Utils.web3.utils.toWei(this.state.buyInputValue.toString()),
                from:this.props.address,
                gasPrice: 12000000000
              })
              .on('transactionHash', (hash)=>{
                console.log(hash);
                message.success(this.props.languageFile.notification.transactionSuccess,4);
              })
              .then(res=>{
                this.fetchContractData();
                this.props.fetchContractData();
                message.success(this.props.languageFile.notification.transactionCompelted,4);
              })
              .catch(err=>{
                console.log(err);
                message.error(this.props.languageFile.notification.transactionFailed,4);
              })
            }
            else{
              message.error(this.props.languageFile.notification.invalidBuyAmount,4);
            }
          }
          else{
            message.success(this.props.languageFile.notification.comingSoon);
          }
        }
      }else{
        // message.warning(this.props.languageFile.notification.loginPrompt)
      }
    }

    sellToken = async () =>{
      if(Utils.web3 && Utils.swap && await isContract(Utils.swap._address)){
        if(!this.props.address){
          message.warning(this.props.languageFile.notification.loginPrompt)
        }
        else{
          if(checkTime()){
            if(parseFloat(this.state.sellInputValue.toString())>0){

              Utils.swap.methods.sell(Utils.web3.utils.toWei(this.state.sellInputValue.toString())).send({
                value: 0,
                from:this.props.address,
                gasPrice: 12000000000
              })
              .on('transactionHash', (hash)=>{
                console.log(hash);
                message.success(this.props.languageFile.notification.transactionSuccess,4);
              })
              .then(res=>{
                this.fetchContractData();
                this.props.fetchContractData();
                message.success(this.props.languageFile.notification.transactionCompelted,4);
              })
              .catch(err=>{
                console.log(err);
                message.error(this.props.languageFile.notification.transactionFailed,4);
              })

            }
            else{
              message.error(this.props.languageFile.notification.invalidSellAmount,4);
            }
          }
          else{
            message.success(this.props.languageFile.notification.comingSoon);
          }
        }
      }else{
        // message.warning(this.props.languageFile.notification.loginPrompt)
      }
    }


    reInvest = async () =>{
      if(Utils.web3 && Utils.swap && await isContract(Utils.swap._address)){
        if(!this.props.address){
          message.warning(this.props.languageFile.notification.loginPrompt)
        }
        else{
          if(checkTime()){
            if(this.props.tokenStatus.myTotalDividends>0){
              Utils.swap.methods.reinvest().send({
                value: 0,
                from:this.props.address,
                gasPrice: 12000000000
              })
              .on('transactionHash', (hash)=>{
                console.log(hash);
                message.success(this.props.languageFile.notification.transactionSuccess,4);
              })
              .then(res=>{
                this.fetchContractData();
                this.props.fetchContractData();
                message.success(this.props.languageFile.notification.transactionCompelted,4);
              })
              .catch(err=>{
                console.log(err);
                message.error(this.props.languageFile.notification.transactionFailed,4);
              })
            }
            else{
              message.error(this.props.languageFile.notification.insufficientDividendsBalance,4);
            }
          }
          else{
            message.success(this.props.languageFile.notification.comingSoon);
          }
        }
      }else{
        // message.warning(this.props.languageFile.notification.loginPrompt)
      }

    }

    withdraw = async () =>{
      if(Utils.web3 && Utils.swap && await isContract(Utils.swap._address)){
        if(Utils.web3 && !this.props.address){
          message.warning(this.props.languageFile.notification.loginPrompt)
        }
        else{
          if(checkTime()){
            if(this.props.tokenStatus.myTotalDividends>0){
              Utils.swap.methods.withdraw().send({
                value: 0,
                from:this.props.address,
                gasPrice: 12000000000
              })
              .on('transactionHash', (hash)=>{
                console.log(hash);
                message.success(this.props.languageFile.notification.transactionSuccess,4);
              })
              .then(res=>{
                this.fetchContractData();
                this.props.fetchContractData();
                message.success(this.props.languageFile.notification.transactionCompelted,4);
              })
              .catch(err=>{
                console.log(err);
                message.error(this.props.languageFile.notification.transactionFailed,4);
              })

            }
            else{
              message.error(this.props.languageFile.notification.insufficientDividendsBalance,4);
            }
          }
          else{
            message.success(this.props.languageFile.notification.comingSoon);
          }

        }
      }else{
        // message.warning(this.props.languageFile.notification.loginPrompt)
      }
      // message.success(this.props.languageFile.notification.comingSoon);
    }


    tipFormatter = (string)  =>{
      return string+"%"
    }

    isMobile = () =>{
      if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
        return true;
      }
      else{
        return false;
      }
    }
    render(){

      return(
        <div className="investment">
          <div className={"buySell"}>

            <div className={"tabSelector"}>
              <div onClick={()=>{this.setState({tab:"buy"})}} className={this.state.tab === 'buy' ? "activeTab" : ""}>
                BUY
              </div>
              <div onClick={()=>{this.setState({tab:"sell"})}} className={this.state.tab === 'sell' ? "activeTab" : ""}>
                SELL
              </div>
            </div>
            {
              this.state.tab === 'buy' ?
                <div className="cardDisplay purchaseBox" style={{backgroundColor:"#E58F0E"}}>
                <div className="bgImg">
                  <img src={LargeBurger} alt='burger' />
                </div>

                <div  className="verticalTextContainer" align="middle">
                  <h2>BUY BURGERS</h2>

                  <Input
                    placeholder="Amount Of BNB"
                    value={this.state.buyInputValue}
                    suffix={
                      <span>
                        <span className="max" onClick={()=>{this.maxBuy()}}>{this.props.languageFile.investSection.max}</span>
                      </span>}
                    onChange={(e)=>this.onBuyValueChange(e.target.value)}
                  />
                  <p className="clickableButton" onClick={()=>{this.buyToken()}}>Buy {numeral(this.state.diaBuy).format('0,0.[00]')} Burgers</p>
                  <p className="balance">{this.props.languageFile.investSection.balance} {numeral(this.state.bnbBalance).format('0,0.000000')} BNB</p>
                </div>
              </div>
                :

                <div className="cardDisplay purchaseBox" style={{backgroundColor:"#E58F0E"}}>
                  <div className="bgImg">
                    <img src={LargeBurger} alt='burger' />
                  </div>
                  <div  className="verticalTextContainer" align="middle">
                    <h2>SELL BURGERS</h2>

                    <Input
                      placeholder="Amount Of BURGER"
                      value={this.state.sellInputValue}
                      suffix={
                        <span>
                          <span className="max" onClick={()=>{this.maxSell()}}>{this.props.languageFile.investSection.max}</span>
                        </span>}
                      onChange={(e)=>this.onSellValueChange(e.target.value)}
                    />
                    <p className="clickableButton" onClick={()=>{this.sellToken()}}>
                      Sell {numeral(this.state.bnbSell).format('0,0.[0000]')} BNB
                    </p>
                    <p className="balance">{this.props.languageFile.investSection.balance} {numeral(this.props.tokenStatus.myTokenBalance).format('0,0.000000')} BURGER</p>
                  </div>
                </div>
            }
          </div>

          <Row type="flex" justify="space-between" align="middle" gutter={30}>
            <Col xs={24} sm={24} md={12}>
              <div className="cardDisplay purchaseBox">
                <div  className="" align="middle">
                  <div className="withdrawTop">
                    <img  src={Burger} style={{verticalAlign:"middle", width: 'auto'}} alt='ill1' height="100px"/>
                    <p style={{verticalAlign:"middle",fontWeight:"bold",fontSize:"20px", margin: "10px 0 0 0"}} className = "middleWords">
                      Mining Power
                    </p>
                    <h1>{numeral(this.props.tokenStatus.myTokenBalance).format('0,0.00')} Burgers</h1>
                    <p
                      className="clickableButton"
                      onClick={()=>{this.reInvest()}}
                      style={{marginTop:"10px", width:"90%",border:"2px solid #FEBF33",color: "#FEBF33"}}>
                      Boost More Burgers
                    </p>
                  </div>
                </div>
              </div>
            </Col>
            <Col xs={24} sm={24} md={12}>
              <div className="cardDisplay purchaseBox">
                <div  className="" align="middle">
                  <div className="withdrawTop">
                    <img  src={BNBLogo} style={{padding:"10px", width: 'auto'}} alt='ill1' height="100px"/>
                    <p style={{verticalAlign:"middle",fontWeight:"bold",fontSize:"20px", margin: "10px 0 0 0"}} className = "middleWords">
                      BNB Mined
                    </p>
                    <h1>{numeral(this.props.tokenStatus.myTotalDividends).format('0,0.[000000]')} BNB</h1>
                    <p
                      className="clickableButton"
                      onClick={()=>{this.withdraw()}}
                      style={{marginTop:"10px", width:"90%", border:"2px solid #FEBF33", color: "#FEBF33"}}>
                      Pocket Your BNB
                    </p>
                  </div>
                </div>
              </div>
            </Col>
          </Row>

        </div>
      )
    }

    maxSell = () =>{
      this.onSellValueChange(this.props.tokenStatus.myTokenBalance)
    }

    maxBuy =() =>{
      this.onBuyValueChange(this.state.bnbBalance*1 - 0.005)
    }

  }


  export default Investment;
