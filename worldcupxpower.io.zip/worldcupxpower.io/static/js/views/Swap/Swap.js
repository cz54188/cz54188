import React, {Component} from 'react';
import Investment from "./Investment";
import {Utils, numeral, SWAP_RELEASE_TIME, checkTime, ROAST_TIME} from "../../utils/utils.js";
import CountDown from '../../components/Countdown/Countdown.js';
import CountdownLoop from '../../components/Countdown/CountdownLoop.js';
import ReferralSection from "../../components/Referral/Referral";
import Faq from "../../components/Faq/Faq";
import BNBLogo from "../../assets/images/BNBlogo.png";
import Burger from "../../assets/images/burger.png";
import BurgerIcon from "../../assets/images/burgerIcon.png";
import Treasury from "../../assets/images/treasury.png";
import './Swap.scss';

let timer = null;
let timeoutTimer = null;
class Swap extends Component{
  constructor(props){
    super(props);
    this.state={
      myTokenBalance:0,
      myDividends:0,
      reInvestTokenReceived: 0,
      myTokenValue:0,
      myDividendsValue:0,
      referralDividends: 0,
      referralDividendsValue:0,
      myTotalDividends:0,
      myTotalDividendsValue:0,
      totalDividends:0,
      totalDividendsValue:0,
      tradingVolume:0,
      tradingVolumeValue:0,
      logId:[],
      balance:0
    };

  }

  componentDidUpdate(prevProps) {

    if((this.props.address !== prevProps.address || this.props.state.bnbPrice !== prevProps.state.bnbPrice) && Utils.web3){
      this.checkContract();
    }
  }

  componentWillUnmount = () =>{
    clearInterval(timer);
    clearTimeout(timeoutTimer);
  }

  componentDidMount = () =>{
    timer = setInterval(()=>{this.checkContract()}, 1000);
  }

  checkContract = () =>{
    if(Utils.web3 && this.props.address){
      clearInterval(timer);
      if(Utils.swap && checkTime()){
        this.fetchContractData();
      }
      else{
        this.getMyBalance();
      }
    }
  }

  fetchContractData = async () =>{
      clearTimeout(timeoutTimer);
      this.getMyBalance();

      const myTokenBalance = await Utils.swap.methods.balanceOf(this.props.address).call({from: this.props.address})
      this.tokenToEth(myTokenBalance);

      const myDividendsWithoutRef = await Utils.swap.methods.myDividends(false).call({from: this.props.address});
      const myDividends = Math.floor(Utils.web3.utils.fromWei(myDividendsWithoutRef)*1000000)/1000000;
      const myDividendsValue = Math.floor(myDividends * this.props.state.bnbPrice * 1000000) / 1000000;

      const myDividendsWithRef = await Utils.swap.methods.myDividends(true).call({from: this.props.address});
      const referralDividends = Math.floor(Utils.web3.utils.fromWei((parseInt(myDividendsWithRef)-parseInt(myDividendsWithoutRef)).toString())*1000000)/1000000;
      const referralDividendsValue = Math.floor(referralDividends * this.props.state.bnbPrice * 1000000) / 1000000
      const myTotalDividends = Math.floor(Utils.web3.utils.fromWei((parseInt(myDividendsWithRef)).toString())*1000000)/1000000;
      const myTotalDividendsValue = Math.floor(myTotalDividends * this.props.state.bnbPrice * 1000000) / 1000000
      this.ethToMiners(myDividendsWithRef);

      this.setState({
        myTokenBalance:Utils.web3.utils.fromWei(myTokenBalance),
        myDividends:myDividends,
        myDividendsValue:myDividendsValue,
        referralDividends:referralDividends,
        referralDividendsValue:referralDividendsValue,
        myTotalDividends:myTotalDividends,
        myTotalDividendsValue:myTotalDividendsValue
      })

      timeoutTimer = setTimeout(()=>{
        this.fetchContractData();
      },6000);
  }

  getMyBalance = () => {
    if(Utils.swap && Utils.web3 && this.props.address){

      Utils.web3.eth.getBalance(this.props.address)
      .then( (res)=>{
        this.setState({
          balance: Math.floor(Utils.web3.utils.fromWei(res) * 1000)/1000,
        })
      })
      .catch(console.log)
    }
  }

  ethToMiners=(eth)=>{
    if(Utils.swap && eth >= 0){
      Utils.swap.methods.calculateTokensReceived(eth).call({
        from: this.props.address
      })
      .then(res => {
        this.setState({
          reInvestTokenReceived:Math.floor(Utils.web3.utils.fromWei(res)*10000)/10000
        })
      })
      .catch(err =>console.log(err))
    }
  }

  tokenToEth=(token)=>{
    if(Utils.swap && token>0){
      Utils.swap.methods.calculateEthereumReceived(token).call({
        from: this.props.address
      })
      .then(res => {
        this.setState({
          myTokenValue:Math.floor(Utils.web3.utils.fromWei(res) * 1000) / 1000 * this.props.state.bnbPrice
        })
      })
      .catch(err =>console.log(err))
    }
  }

  isMobile = () =>{
    if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
      return true;
    }
    else{
      return false;
    }
  }

  render(){
    return(
      <div className="token">
        <div className="banner" align="middle">
          <div className="promptSection">
            <h1>BeefSwap</h1>
            <h2>Buy & Sell Burger tokens in BeefSwap and earn trading dividends in BNB.</h2>
            <p>Buy Dividends — 20%  Sell Dividends — 10%</p>
            <p>Referral Bonus — 15%</p>
            <p>Dev Fee — 1.5%</p>
            <p>Treasury: 5% of sell fees goes Treasury and will support Roast Beef Contract every 72 hours</p>

            {
              checkTime(SWAP_RELEASE_TIME)
                ?
                  null
                :
                <div className="countdownWrapper">
                  <CountDown date={SWAP_RELEASE_TIME}/>
                  <p>{SWAP_RELEASE_TIME}</p>
                </div>
            }

          </div>

        </div>

        <div className="dataContainer" align="middle">
          <div className="dataBoxWrap">
            <div className="rainbowWrap">
              <div className="rainbow">
              </div>
            </div>
            <div className="dataBox">
              <img src={BNBLogo}  alt="png"/>
              <div>
                <h2>
                  {numeral(this.props.state.marketcap).format("0,0.[0000]")} BNB
                </h2>
                <p>Contract Balance</p>
              </div>

            </div>
          </div>

          <div className="dataBoxWrap">
            <div className="rainbowWrap">
              <div className="rainbow">
              </div>
            </div>
            <div className="dataBox">
              <img src={Burger}  alt="png"/>
              <div>
                <h2>
                  {numeral(this.props.state.totalSupply).format("0,0")} BURGER
                </h2>
                <p>Total Burgers</p>
              </div>

            </div>
          </div>

          <div className="dataBoxWrap">
            <div className="rainbowWrap">
              <div className="rainbow">
              </div>
            </div>
            <div className="dataBox">
              <img src={BurgerIcon}  alt="png"/>
              <div>
                <h2>
                  {this.props.state.tokenPrice} BNB
                </h2>
                <p>Burger Price</p>
              </div>

            </div>
          </div>

          <div className="dataBoxWrap">
            <div className="rainbowWrap">
              <div className="rainbow">
              </div>
            </div>
            <div className="dataBox">
              <img src={Treasury}  alt="png"/>
              <div>
                <h2>
                  {numeral(this.props.state.treasury).format("0,0.[0000]")} BNB
                </h2>
                <p>Treasury</p>
              </div>

              <div className={"roastTime"}>
               Roast In <CountdownLoop date={ROAST_TIME}/>
              </div>

            </div>
          </div>

        </div>
        <div className={"innerWrap"}>
          <Investment tokenStatus={this.state} bnbPrice = {this.props.state.bnbPrice} languageFile={this.props.languageFile} lang={this.props.lang} address={this.props.address} fetchContractData={this.fetchContractData}/>
          <ReferralSection languageFile={this.props.languageFile} lang={this.props.lang} address={this.props.address} totalSupply={this.props.state.totalSupply}/>
          <div className="faqHeader">
            <h1>BeefSwap: Investors can buy and sell Burger tokens FREELY</h1>
            <p>Through the smart contract and earn 10% - 20% daily cash flow from the swap trading fees.</p>
          </div>
          <Faq languageFile={this.props.languageFile}/>
        </div>

      </div>

    )
  }
}

export default Swap;
