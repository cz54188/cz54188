import React, {Component} from 'react';
import {message} from 'antd';
import {numeral, Utils} from "../../utils/utils";
import {CopyToClipboard} from 'react-copy-to-clipboard';
import './FarmReferral.scss';
const LINK = `${window.location.origin}/#/farm?ref=`;
class FarmReferral extends Component{
  constructor(props) {
    super(props);
    this.state = {
      refLink: LINK + props.address
    }
  }
  componentDidUpdate = (prevProps) =>{
    if(this.props.address !== prevProps.address){

      this.setState({
        refLink: LINK + this.props.address
      })
       this.checkContract();
    }
  }

  componentDidMount = () => {
    this.timer = setInterval(()=>{this.checkContract()}, 1000);
  }

  componentWillUnmount = () =>{
    clearInterval(this.timer);
    clearTimeout(this.timeoutTimer);
  }

  checkContract=()=>{
    if(Utils.web3 && Utils.poolReferral && this.props.address){
      clearInterval(this.timer);
      this.getRefData();
    }
  }

  getRefData = async () => {
    try{
      const totalReferrals = await Utils.poolReferral.methods.inviteeAmount(this.props.address).call();
      const referralClaimed = await Utils.poolReferral.methods.accumulatedBonuses(this.props.address).call();
      const availableReferrals = await Utils.poolReferral.methods.bonuses(this.props.address).call();
      // const inviter = await Utils.poolReferral.getInviter(this.props.address).call();

      this.setState({
        totalReferrals:totalReferrals,
        referralClaimed: Utils.web3.utils.fromWei(referralClaimed),
        availableReferrals:Utils.web3.utils.fromWei(availableReferrals),
      })

    }catch (e){
      console.log(e)
    }

    this.getPoolStatsTimer = setTimeout(() => {
      this.getRefData();
    }, 6000);
  }
  render(){
    return(
      <div className="farmReferral" align="left">
        <div className={"innerWrapper"}>
          <div className={"title"}>
           Invite your friends to earn rewards from their staking rewards.
          </div>
          <div className={"refIntro"}>
            Every direct referral provides 10% income on all farms and pools staking rewards claims. Referral rewards are paid in RBD tokens. You must stake in one of the pools to active your referral link.
          </div>
          <div className={'refLinkWrap'}>
            <div className={"link"}>{
              this.props.address ?
              this.state.refLink
                :"Connect Wallet to get referral link"
            }</div>
            {
              this.props.address ?
                <CopyToClipboard text={this.state.refLink} onCopy={() => message.success('Copied to clipboard')}>
                  <div className={"copyButton"}>
                    COPY
                  </div>
                </CopyToClipboard>
                :
                  null
                }
          </div>
          <div className={"refStatus"}>
            <div>
              <h2>Total Referrals</h2>
              <h1>{numeral(this.state.totalReferrals).format('0,0')}</h1>
            </div>
            <div>
              <h2>Referral Claimed</h2>
              <h1>{numeral(this.state.referralClaimed).format('0,0.[00]')} RBD</h1>
            </div>
            <div className={"availableReferrals"}>
              <div>
                <h2>Available</h2>
                <h1>{numeral(this.state.availableReferrals).format('0,0.[00]')} RBD</h1>
              </div>

              <div className={"claimButton"} onClick={this.harvest}>
                Claim
              </div>
            </div>
          </div>
        </div>

      </div>
    )
  }

  harvest = () =>{
    if(Utils.poolReferral && this.state.availableReferrals > 0){
      Utils.poolReferral.methods.getBonus().send({
        from: this.props.address
      })
        .on('transactionHash', (hash) => {
            console.log(hash)
            message.info("Transaction sent", 3)
          })
	    .catch(err => console.log(err))
    }
  }
}

export default FarmReferral;
