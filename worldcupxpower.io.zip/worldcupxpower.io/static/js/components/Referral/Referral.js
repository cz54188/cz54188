import React, {Component} from 'react';
import {Row, Col,message} from 'antd';
import {Utils} from "../../utils/utils";
import {CopyToClipboard} from 'react-copy-to-clipboard';
import Circle from "../../assets/images/circle.png"
import './Referral.scss';

let languageFile = null;
const REFLINK = 'https://roastedbeef.io/#/swap?ref=';
// const REFLINK = 'http://192.168.1.24:3000?ref=';
let timer = null;
class Referral extends Component{

  constructor(props){
    super(props);
    this.state={
      visible: false,
      width:60,
      referralLink:REFLINK,
      affCount1Sum:0,
      affCount2Sum:0,
      affCount3Sum:0,
      tierInvest1Sum:0,
      tierInvest2Sum:0,
      tierInvest3Sum:0,
      totalRewarded:0
    };
    var currentLang = sessionStorage.getItem('lang') || 'en';
    languageFile=require('../../assets/languages/'+currentLang+'.json');
  }



  componentDidUpdate = (prevProps) => {

    if(this.props.address !== prevProps.address){
      this.checkContract()
      this.setState({
        referralLink: REFLINK+this.props.address
      })

    }

    if(this.props.totalSupply !== prevProps.totalSupply){
      this.checkContract();
    }
  }

  componentWillUnmount = () =>{
    clearInterval(timer);
  }

  componentDidMount = () =>{
    timer = setInterval(()=>{this.checkContract()}, 1000);
    this.setState({
      referralLink: REFLINK+this.props.address
    })
  }

  checkContract=()=>{
    if(Utils.swap && Utils.web3 && this.props.address){
      clearInterval(timer);
      this.fetchReferralData();
    }
  }

  fetchReferralData = () =>{
    Utils.swap.methods.referralData(this.props.address).call({
      from: this.props.address
    })
    .then(res => {

      this.setState({
        affCount1Sum:res.affCount1Sum,
        affCount2Sum:res.affCount2Sum,
        affCount3Sum:res.affCount3Sum,
        tierInvest1Sum:Math.floor(Utils.web3.utils.fromWei(res.tierInvest1Sum)*100)/100,
        tierInvest2Sum:Math.floor(Utils.web3.utils.fromWei(res.tierInvest2Sum)*100)/100,
        tierInvest3Sum:Math.floor(Utils.web3.utils.fromWei(res.tierInvest3Sum)*100)/100
      },()=>{
        this.setState({
          totalRewarded:(this.state.tierInvest1Sum * 7 / 100 + this.state.tierInvest2Sum * 5 / 100 +this.state.tierInvest3Sum * 3 / 100).toFixed(4)
        })
      })
    })
    .catch(err =>console.log(err))
  }

  render(){
    return(
      <div className="InvestmentSection ReferralInvest" >
        <div className="investPrompt">
          <h2>{this.props.languageFile.referral.title}</h2>
        </div>
        <div className="referralLinkSection" align="middle">
          <div className="referralLinkInner" align="middle">
            <h2>{this.props.languageFile.referral.inviteLink}</h2>
            <div className={"linkWrapper"}>
              <p className="referralLink">{this.state.referralLink} </p>
              <div className="copyButton" align="left">
                <CopyToClipboard text={this.state.referralLink}
                  onCopy={() => { message.success(languageFile.referral.copySuccess)}}>
                  <span>{this.props.languageFile.referral.copy}</span>
                </CopyToClipboard>
              </div>
            </div>

            <p className="smallNote">Your Tier 1 referral masternode is auto activated when you connected to your wallet. You need 1000 burgers to activate your referral masternodes</p>
          </div>

        </div>
        <div align="middle" className="referralStatus">
          <div className="totalRewards" align="middle">
            <h2>{this.props.languageFile.referral.totalRewards}</h2>
            <h1>{this.state.totalRewarded} BNB</h1>
          </div>
          <div className={"referralTierSection"}>
              <div className={"item"}>
                <div className={"tierWrapper"}>
                  <img src={Circle} alt={"png"}/>
                  <div className={"tier"}>
                    <h2>Tier 1</h2>
                    <p>7% Reward</p>
                  </div>
                </div>
                <p>Total Referrals: {this.state.affCount1Sum}</p>
                <p>Total Invested: {this.state.tierInvest1Sum}</p>
              </div>
              <div className={"dotLine"}/>
              <div className={"item"}>
                  <div className={"tierWrapper"}>
                  <img src={Circle} alt={"png"}/>
                  <div className={"tier"}>
                    <h2>Tier 2</h2>
                    <p>5% Reward</p>
                  </div>
                </div>
                  <p>Total Referrals: {this.state.affCount2Sum}</p>
                  <p>Total Invested: {this.state.tierInvest2Sum}</p>
              </div>
              <div className={"dotLine"}/>
              <div className={"item"}>
                  <div className={"tierWrapper"}>
                  <img src={Circle} alt={"png"}/>
                  <div className={"tier"}>
                    <h2>Tier 3</h2>
                    <p>3% Reward</p>
                  </div>
                </div>
                  <p>Total Referrals: {this.state.affCount3Sum}</p>
                  <p>Total Invested: {this.state.tierInvest3Sum}</p>
              </div>
          </div>
        </div>

      </div>

    )
  }
}

export default Referral;
