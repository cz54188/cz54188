import React, {Component} from 'react';
import {Row, Col} from 'antd';
import Sustainability from "../../assets/images/sustainability.png";
import Lock from "../../assets/images/lock.png";
import BurgerIcon from "../../assets/images/burgerIcon.png";
import Star from "../../assets/images/star.png"
import './Faq.scss';
import {SwapAddress} from "../../utils/utils";

class Faq extends Component{

  render(){
    return(
      <div className="faq">
        {/* <h1>{this.props.languageFile.faq.faq}</h1> */}
        <div className="faqItemBox">
          <img src={Sustainability} alt={"png"}/>
          <p className="question">{this.props.languageFile.faq.q1}</p>
          <p className="answer">Unlike other ROI projects which will eventually run out of funds and drain the contract, BeefSwap invented a unique algorithm to generates stable daily cash flow for investors through BeefSwap trading fees by simply holding Burger Tokens. Burgers can be bought and sold at anytime through the BeefSwap smart contract and investors will receive huge capital gains.</p>
        </div>
        <div className="faqItemBox">
          <img src={Lock} alt={"png"}/>
          <p className="question">Verified Smart Contract</p>
          <p className="answer">The BeefSwap contract is fully open source and VERIFIED on <a href={`https://www.bscscan.com/address/${SwapAddress}#code`} target={"_blank"} rel="noopener nore">BSCSCAN.COM</a> and found NO backdoors and NO rugpull functions.</p>
        </div>
        <div className="faqItemBox">
          <img src={BurgerIcon} alt={"png"}/>
          <p className="question">What makes BeefSwap so special?</p>
          <p className="answer">Holding onto Burger tokens means you are continuously mining free BNB every single time any other users buys, sells or transfers Burgers. Many holders often report earnings between 10%-30% of their holdings on a daily basis, though this fluctuates heavily based on transaction volume.</p>
        </div>
        <div className="faqItemBox">
          <img src={Star} alt={"png"}/>
          <p className="question">Burger Token Info</p>
          <p className="answer">BeefSwap taxes 20% trading fees for buying and 10% for selling burgers and the fees are instantly distributed to all Burger token holder in the form of BNB. The more Burger tokens you hold means the higher mining power you have, therefore the more BNB you can mine.</p>
          <p className="answer">The object of the game is buying and compounding more burger tokens, sooner and more often than other players. This in turn earns you more BNB faster. Compounding burgers using your daily BNB earnings will increase your burger token amount and mining power therefore to earn you more BNB day by day.</p>
        </div>

      </div>
    )
  }
}

export default Faq;
