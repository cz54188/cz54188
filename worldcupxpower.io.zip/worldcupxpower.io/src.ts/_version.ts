export const version = "abi/5.6.1";
//# sourceMappingURL=_version.js.map